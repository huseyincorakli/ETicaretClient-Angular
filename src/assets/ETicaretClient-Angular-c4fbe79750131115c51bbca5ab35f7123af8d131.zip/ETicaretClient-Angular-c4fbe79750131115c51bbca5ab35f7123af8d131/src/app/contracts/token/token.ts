export class Token{
    accessToken:string;
    expiration:Date;
    refreshToken:string;
}