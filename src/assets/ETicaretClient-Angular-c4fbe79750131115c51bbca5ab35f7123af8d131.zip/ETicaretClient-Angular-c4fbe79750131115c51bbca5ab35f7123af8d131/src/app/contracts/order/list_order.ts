export class List_Order{
    orderCode:string;
    userName:string;
    totalPrice:string;
    createdDate:Date;
    completed:boolean;
}