export class User {
    nameSurname: string;
    username: string;
    email: string;
    password: string;
    passwordConfirm: string;
  }