export class List_Product_Tags {
    id:string;
    createDate:Date
    updatedDate:Date
    tagName:string;
    categoryId:string;
    isActive:boolean;

}