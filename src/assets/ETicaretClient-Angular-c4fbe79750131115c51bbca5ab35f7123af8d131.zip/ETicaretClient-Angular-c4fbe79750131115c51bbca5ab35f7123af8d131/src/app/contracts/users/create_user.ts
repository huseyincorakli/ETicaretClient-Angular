export class Create_User{
   succeeded:boolean;
   message:string;
}