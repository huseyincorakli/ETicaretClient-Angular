export enum ReceiveFunctions {
    ProductAddedMessageReceiveFunction="receiveProductAddedMessage",
    OrderAddedMessageReceiveFunction = "receiveOrderAddedMessage"
}
