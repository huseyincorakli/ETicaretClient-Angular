export class Get_Message{
 email:string;
 messageTitle:string;
 messageContent:string;
 id:string;
 createDate:Date;
    
}


