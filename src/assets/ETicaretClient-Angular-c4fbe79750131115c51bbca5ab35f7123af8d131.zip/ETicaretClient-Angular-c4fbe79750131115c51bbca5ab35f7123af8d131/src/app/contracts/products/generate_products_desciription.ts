export class GenerateProductDescription {
    brand: string;
    category: string;
    description: string;
    keywords: string[];
    name: string
}