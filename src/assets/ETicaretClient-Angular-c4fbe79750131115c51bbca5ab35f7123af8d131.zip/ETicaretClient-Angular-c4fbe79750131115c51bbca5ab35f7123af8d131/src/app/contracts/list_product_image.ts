
export class List_Product_Image{
    id:string;
    path:string;
    fileName:string;
    showcase:boolean;
}