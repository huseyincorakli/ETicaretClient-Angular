export class BaseUrl{
    url:string;
}