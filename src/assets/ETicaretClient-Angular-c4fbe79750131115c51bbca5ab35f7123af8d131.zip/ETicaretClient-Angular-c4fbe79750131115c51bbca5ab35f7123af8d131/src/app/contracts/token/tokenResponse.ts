import { Token } from "./token";

export class TokenResponse{
    token :Token;
    role:string;
    userId:string;
}