export class Create_Comment{
    ProductId:string;
    CommentContent:string;
    CommentTitle:string;
    NameSurname:string;
    Score:number;
    UserId:string;
}
