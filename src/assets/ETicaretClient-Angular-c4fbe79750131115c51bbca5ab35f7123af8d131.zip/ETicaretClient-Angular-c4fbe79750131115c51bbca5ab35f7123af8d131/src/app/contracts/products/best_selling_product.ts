
export class Best_Selling_Product{
   bestSellingProducts:obj[]
}
export class obj{
   id:string;
  name:string;
  quantitySold:string;
}