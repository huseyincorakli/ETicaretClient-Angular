export class CreateCategory{
    categoryName:string;
    isActive:boolean;
}