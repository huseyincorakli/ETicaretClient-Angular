export class List_Basket_Item {
    basketItemId:string;
    name:string;
    price:number;
    quantity:number;
    totalPrice:number;
    productId:string;
    imagePath:string;
}
