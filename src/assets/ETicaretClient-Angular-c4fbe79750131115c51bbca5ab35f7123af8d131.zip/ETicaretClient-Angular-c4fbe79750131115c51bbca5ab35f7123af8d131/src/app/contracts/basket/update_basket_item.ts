export class Update_Basket_Item{
    basketItemId:string;
    quantity:number;
}