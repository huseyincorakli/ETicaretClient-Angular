import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommentService } from 'src/app/services/common/models/comment.service';
import { SharedCommentService } from 'src/app/services/common/models/shared-comment.service';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.scss']
})
export class CommentsComponent implements OnInit {

  constructor(
    private commentService: CommentService,
    private activatedRoute: ActivatedRoute,
    private sharedComment:SharedCommentService) {
  }
  hasComment: boolean = false;
  comments: any = []
  totalCount: number;
  averageScore: number = 0;
  page = 0;
  size = 5;
  totalPages: number;
  userComment: any;
  datax:any;
  productId:string;
  summarizedComment:any;
  isLoading:boolean;
  async ngOnInit() {
    
    this.productId = this.activatedRoute.snapshot.paramMap.get('productId')
    var data = await this.commentService.getCommentsByProductId(this.productId, this.page, this.size);
    this.comments = data.responseData
    this.totalCount = data.totalCount
    this.averageScore = data.avarageScore;
    this.totalPages = Math.ceil(this.totalCount / this.size);
    const userId = localStorage.getItem('userId');
    this.datax = await this.commentService.getComment(this.productId, userId);
    this.hasComment = this.datax.isHas;
    
    if (this.hasComment == true) {
      this.userComment = this.datax.comment
    }
    this.sharedComment.commentSubmitted$.subscribe(async ()=>{
      await this.fetchComments();
     this.datax = await this.commentService.getComment(this.productId, userId);
      this.hasComment = this.datax.isHas;
      if (this.hasComment == true) {
        this.userComment = this.datax.comment
      }
    })
  }
  changePage(offset: number) {
    console.log(offset);

    const newPage = this.page + offset;

    if (newPage >= 0 && newPage < this.totalPages) {
      this.page = newPage;
      this.fetchComments();
    }
  }
  async summarizeComment(){
    this.isLoading=true;
    const summarizeComment =  await this.commentService.summarizeComment(this.productId);
    debugger
    this.summarizedComment =JSON.parse(summarizeComment.responseData);
    debugger;
    this.isLoading=false;
  }
  generateStars(score: number): number[] {
    return Array.from({ length: score }, (_, index) => index + 1);
  }
  getPageIndexes(): number[] {
    return Array(this.totalPages).fill(0).map((_, index) => index);
  }
  
  async fetchComments() {
    const productId = this.activatedRoute.snapshot.paramMap.get('productId');
    const data = await this.commentService.getCommentsByProductId(productId, this.page, this.size);
    this.comments = data.responseData;
    this.totalCount = data.totalCount;
    this.averageScore = data.avarageScore;

    this.totalPages = Math.ceil(this.totalCount / this.size);
  }

}
