export class Create_ShippingCompany{
    companyName:string;
    companyUrl:string;
}