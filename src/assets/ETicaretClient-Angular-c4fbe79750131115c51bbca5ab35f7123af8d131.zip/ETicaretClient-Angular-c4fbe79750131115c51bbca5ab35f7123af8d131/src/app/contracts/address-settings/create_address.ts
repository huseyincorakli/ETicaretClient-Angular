export class Create_Address{
nameSurname:string;
userId:string;
telNumber:string;
city:string;
county:string;
addressInfo:string;
directions:string;
}

