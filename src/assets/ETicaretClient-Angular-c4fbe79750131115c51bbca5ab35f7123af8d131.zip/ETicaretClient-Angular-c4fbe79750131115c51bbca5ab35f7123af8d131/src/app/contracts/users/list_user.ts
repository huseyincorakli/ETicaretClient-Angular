export class List_User{
    id:string;
    email:string;
    nameSurname:string;
    userName:string;
    twoFactorEnabled:boolean;
    
}