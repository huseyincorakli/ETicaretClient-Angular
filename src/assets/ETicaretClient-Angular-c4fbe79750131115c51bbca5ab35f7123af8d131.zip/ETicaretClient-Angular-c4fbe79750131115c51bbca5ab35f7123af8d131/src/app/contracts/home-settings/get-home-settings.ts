export class Get_Home_Setting{
    id:string;
    numberOfFeaturedProducts:number;
    welcomeText:string;
    welcomeTitle:string;
    contactNumber:string;
    contactAddress:string;
    contactMail:string;
}
