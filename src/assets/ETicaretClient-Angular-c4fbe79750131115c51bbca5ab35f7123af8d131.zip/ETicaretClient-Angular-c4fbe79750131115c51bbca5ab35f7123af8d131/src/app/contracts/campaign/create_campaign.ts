export class Create_Campaign {
    title: string;
    code: string;
    content: string;
    expiredTime: Date;
    showCase: boolean=false;
    discountPercentage:number;
}