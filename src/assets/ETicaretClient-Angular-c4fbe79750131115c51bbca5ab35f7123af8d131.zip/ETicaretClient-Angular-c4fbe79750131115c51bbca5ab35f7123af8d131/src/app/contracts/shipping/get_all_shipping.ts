export class GetAll_ShippingCompanies
{
    companyName:string;
    companyUrl:string;
    id:string;
    createDate:Date;
    updatedDate:Date;

}

// {
//     "companyName": "MNG KARGO",
//     "companyUrl": "https://www.mngkargo.com.tr/gonderitakip",
//     "orders": null,
//     "id": "13bb7dd0-36bc-43da-9c2d-2c91f39b52a5",
//     "createDate": "2023-12-17T11:01:36.394224Z",
//     "updatedDate": "0001-01-01T00:00:00"
//   }