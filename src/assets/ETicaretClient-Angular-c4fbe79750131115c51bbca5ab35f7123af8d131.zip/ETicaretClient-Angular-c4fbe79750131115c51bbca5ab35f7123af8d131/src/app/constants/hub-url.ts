export enum  HubUrls{
    ProductHub="products-hub",
    OrderHub="orders-hub"
}