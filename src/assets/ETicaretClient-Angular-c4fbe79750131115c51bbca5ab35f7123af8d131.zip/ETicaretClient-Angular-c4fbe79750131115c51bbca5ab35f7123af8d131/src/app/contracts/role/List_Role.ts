export class List_Role{
    id:string;
    name:string;
}