

export class Product_Details{
    
    name:string;
    stock:number;
    price:number;
    imageFiles?:any[];
    categoryName:string;
    description?:string;
    shortDesciription:string;
    brand:string;
    specifications:string[];
}