
export class Low_Stock_Product{
   lowStockProducts:lowStockProducts[]
}
export class lowStockProducts{
    id:string;
    name:string;
    stock:number
}