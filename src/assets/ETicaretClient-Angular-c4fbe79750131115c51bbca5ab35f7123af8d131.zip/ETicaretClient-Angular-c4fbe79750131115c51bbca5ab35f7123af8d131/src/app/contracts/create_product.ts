export class Create_Product {
    name:string;
    stock:number;
    price:number; 
    description:string;
    categoryId:string;
    shortDesciription:string;
    brand:string;
    specifications:string[];
}
