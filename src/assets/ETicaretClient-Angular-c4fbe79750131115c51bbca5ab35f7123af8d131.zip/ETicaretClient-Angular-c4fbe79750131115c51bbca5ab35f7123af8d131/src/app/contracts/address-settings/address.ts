export class Address{
    city:string;
    country:string;
    county:string;
    name?:string;
    label:string;
}

