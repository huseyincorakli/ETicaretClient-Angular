export class SingleOrder {
    address: string;
    basketItems: any[];
    createdDate: Date;
    id: string;
    orderCode: string;
    description:string;
    completed:boolean;
}