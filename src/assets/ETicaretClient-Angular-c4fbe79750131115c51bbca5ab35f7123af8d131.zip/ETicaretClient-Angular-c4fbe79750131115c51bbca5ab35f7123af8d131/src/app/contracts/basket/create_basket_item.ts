export class Create_Basket_Item{
    productId:string;
    quantity:number;
}