export class Create_Message{
email:string;
messageTitle:string;
messageContent:string;
}

// namespace ETicaretAPI_V2.Application.DTOs.Message
// {
// 	public class Create_Message
// 	{
// 		public string Email { get; set; }
// 		public string MessageTitle { get; set; }
// 		public string MessageContent { get; set; }
// 	}
// }
