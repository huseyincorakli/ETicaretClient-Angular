export class Get_Comment{
    isHas:boolean;
    comment:object
}